library(testthat)
library(JoesFlow)

test_check("JoesFlow")
